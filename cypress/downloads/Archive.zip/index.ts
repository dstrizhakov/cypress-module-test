import injectDevServer from '@cypress/react/plugins/load-webpack';

export default(on, config) => {
  injectDevServer(on, config, {webpackFilename: './webpack.config.ts' });
  return config;